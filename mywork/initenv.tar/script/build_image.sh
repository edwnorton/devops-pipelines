#!/bin/bash

buildRoot=/build
tomcatRoot=/usr/local/tomcat

cd $tomcatRoot
mkdir -p /data/tomcat
mv webapps /data/tomcat

ln -s /data/tomcat/webapps webapps
