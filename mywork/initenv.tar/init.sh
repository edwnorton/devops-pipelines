#!/bin/bash
#安装环境初始化
sudo yum remove -y docker docker-client docker-client-latest docker-common docker-latest docker-latest-logrotate docker-logrotate docker-engine
sudo yum install -y yum-utils device-mapper-persistent-data lvm2
sudo yum-config-manager --add-repo https://download.docker.com/linux/centos/docker-ce.repo
sudo yum install -y docker-ce
curl -sSL https://get.daocloud.io/daotools/set_mirror.sh | sh -s http://a58c8480.m.daocloud.io
#sudo touch /etc/docker/daemon.json
#sudo chmod 666 /etc/docker/daemon.json
#sudo echo "{"registry-mirrors": ["http://a58c8480.m.daocloud.io"]}" >> /etc/docker/daemon.json
sudo yum install -y java-1.8.0-openjdk  java-1.8.0-openjdk-devel

#docker mirrors文件检测
dfile=/etc/docker/daemon.json
if [ -f $dfile ]; then
    str=`cat /etc/docker/daemon.json|grep ],}`
    if [ -n "$str" ]; then
        sudo sed -i "s/],}/]}/g" `grep "],}" -rl /etc/docker/daemon.json`
    fi
fi

sudo systemctl start docker && sudo systemctl enable docker

#目录初始化
workRootDir=$HOME
myworkRootDir=$HOME/mywork
mkdir -p $workRootDir/tomcat/webapps/hello

#Build image
cd /home/tq
sudo docker build -t edwnorton/tomcat ./

cd $workRootDir/tomcat
if [ -d $workRootDir/tomcat/hello ];then 
    rm -rf hello
    mkdir -p $workRootDir/tomcat/webapps/hello
fi

#删除容器
myTtomcatContainer=`sudo docker ps -a|grep my-tomcat|awk '{print $1}'`
if [ -n "$myTtomcatContainer" ];then
    sudo docker stop $myTtomcatContainer
	sudo docker rm $myTtomcatContainer
fi

#启动容器
sudo docker run -dt --name my-tomcat --mount type=bind,source=$workRootDir/tomcat/webapps,target=/usr/local/tomcat/webapps -p 80:8080 edwnorton/tomcat

